# 🏢 B36 Hall Management System v29 - RBAC

نظام متكامل لإدارة تدفق المرشحين مع نظام أدوار وصلاحيات RBAC كامل

---

## 📁 بنية المشروع

```
b36-system-v29/
├── index.html          # الصفحة الرئيسية
├── styles.css          # التنسيقات
├── app.js              # الكود الرئيسي (Firebase + RBAC)
└── README.md           # هذا الملف
```

---

## 🚀 التثبيت

### الطريقة 1: رفع مباشر على Netlify

1. اذهب إلى https://app.netlify.com
2. اسحب المجلد كاملاً
3. Deploy! ✅

### الطريقة 2: GitHub + Netlify

1. **في GitHub Desktop:**
   ```
   File → New Repository
   Name: b36-system-v29
   ```

2. **انسخ الملفات الأربعة للمجلد**

3. **Commit & Push:**
   ```
   Summary: Initial commit - B36 v29 RBAC
   Commit to main
   Publish repository
   ```

4. **في Netlify:**
   ```
   New site from Git → GitHub
   اختر: b36-system-v29
   Deploy!
   ```

---

## 👥 الأدوار السبعة

| الدور | الاسم | الوصف |
|------|------|-------|
| `مدير_عام` | ADMIN | صلاحيات كاملة |
| `منظم_خارجي_مشرف` | EXTERNAL_SUPERVISOR | إدارة الخارج + إنشاء طلبات |
| `منظم_خارجي_عادي` | EXTERNAL_REGULAR | إدخال أعداد فقط |
| `منظم_داخلي_مشرف` | INTERNAL_SUPERVISOR | إنشاء طلبات داخلية + مراقبة |
| `منظم_داخلي_عادي` | INTERNAL_REGULAR | قبول/رفض طلبات قاعته |
| `منظم_مسار` | PATH_ORGANIZER | تنفيذ عمليات النقل |
| `عارض` | VIEWER | مشاهدة فقط |

---

## 🔑 الحسابات التجريبية

بعد الضغط على "🔧 تهيئة النظام":

| المستخدم | الباسورد | الدور |
|----------|---------|-------|
| `admin` | `1234` | مدير عام |
| `external_supervisor` | `1234` | منظم خارجي مشرف |
| `external_regular` | `1234` | منظم خارجي عادي |
| `internal_supervisor` | `1234` | منظم داخلي مشرف |
| `internal_regular` | `1234` | منظم داخلي عادي |
| `path_organizer` | `1234` | منظم مسار |
| `viewer` | `1234` | عارض |

---

## ✨ المميزات المنفذة

### ✅ المرحلة الأولى (جاهزة):
- ✅ نظام RBAC كامل (7 أدوار)
- ✅ مصفوفة صلاحيات دقيقة
- ✅ Firebase Backend متكامل
- ✅ Audit Logging
- ✅ إدارة الانتظار الخارجي
- ✅ Dashboard مخصص لكل دور
- ✅ Dark Mode
- ✅ Mobile Responsive

### 🔄 المرحلة الثانية (قيد التطوير):
- 🔄 نظام TransferRequests الكامل
- 🔄 Workflows (Outside→Waiting→Interview)
- 🔄 State Machine
- 🔄 نظام المصادقة والتأكيد
- 🔄 إعادة التوزيع بين القاعات
- 🔄 إدارة القاعات والمستخدمين

---

## 📞 الدعم

تم التطوير بواسطة:
- **عبدالرحمن المالكي**
- **عبدالعزيز الأحمدي**
- **عبدالعزيز الذبياني**

Made with ❤️ in Saudi Arabia - 2026
