# 🏢 B36 Hall Management System v33 - Enhanced Edition

نظام إدارة تدفق المرشحين المحدث مع RBAC محكم، Workflow محسّن، Hall Control مع عداد يدوي، Dashboard متقدم، ومنع تضارب الأعداد.

---

## 📋 نظرة عامة

هذا النظام تم تصميمه لإدارة تدفق المرشحين بين ثلاث مناطق رئيسية:
1. **خارج المبنى** (Outside Queue)
2. **قاعات الانتظار** (Waiting Halls)
3. **قاعات المقابلات** (Interview Halls)

يوفر النظام آليات محكمة لضمان دقة الأعداد، تتبع كامل للعمليات، وصلاحيات محددة لكل دور.

---

## ✨ الميزات الرئيسية

### 🔐 RBAC محكم (Role-Based Access Control)
- **6 أدوار ثابتة** مع صلاحيات محددة بدقة
- **التحقق في 3 طبقات**: UI + Frontend Logic + Firestore Rules
- **نطاق القاعة (Hall Scope)**: المستخدمون الداخليون يتفاعلون فقط مع قاعاتهم

### 🔄 Workflow محكم
- **منع الخصم المزدوج (Double Decrement)**: الخصم يحدث مرة واحدة فقط عند `in_transit`
- **State Machine واضح** مع انتقالات محددة
- **3 أنواع من الطلبات**: outside→waiting, waiting→interview, interview→interview
- **تعيين منظم المسار** للطلبات الداخلية

### 🎛️ Hall Control UI (عداد يدوي)
- **Draft → Commit**: تعديل الأعداد يدوياً ثم اعتمادها
- **طلب سبب إلزامي** عند التعديلات الكبيرة أو تجاوز السعة
- **منع العدد السالب** ومنع تجاوز السعة (إلا للـ Admin)
- **تسجيل كامل** لكل عملية Commit في AuditLog

### 📊 Dashboard Command Center
- **KPI Ribbon**: 6 مؤشرات أداء رئيسية (خارج المبنى، داخل المبنى، الطاقة المتبقية، التدفق، نسبة الفروقات)
- **Heatmap Grid**: خريطة حرارية للقاعات مع Sparklines
- **Flow View**: مخطط تدفق (Sankey-like) لتوضيح الحركة
- **Alerts Panel**: تنبيهات تلقائية (قاعات ممتلئة، طلبات معلقة، نقل متعثر)
- **Task Inbox**: صندوق مهام مخصص لكل دور

### 📝 Audit Log شامل
- **تسجيل كل عملية حساسة** مع before/after/reason
- **عرض محدود** حسب الصلاحيات (Admin يرى الكل)

---

## 📁 هيكل الملفات

```
b36-hall-system/
├── index.html                      # الواجهة الرئيسية (من النظام القديم)
├── styles.css                      # الأنماط (من النظام القديم)
├── app.js                          # التطبيق الرئيسي (من النظام القديم)
│
├── ANALYSIS.md                     # تحليل النظام الحالي والمتطلبات الجديدة
├── DATA_MODEL.md                   # تصميم نموذج البيانات والـ Schema
├── DOCUMENTATION.md                # التوثيق الشامل (الأدوار، الانتقالات، الاختبارات)
├── README.md                       # هذا الملف
│
├── firestore.rules                 # قواعد أمان Firestore
├── backend-api.js                  # Backend API مع منطق الصلاحيات المحكم
├── workflow-engine.js              # محرك سير العمل المحكم
├── hall-control-ui.js              # واجهة Hall Control مع العداد اليدوي
├── dashboard-command-center.js     # Dashboard Command Center المتقدم
├── migration-script.js             # سكريبت ترحيل البيانات
├── acceptance-tests.js             # اختبارات القبول
│
├── NEW_FEATURES_README.md          # توثيق الميزات السابقة (من النظام القديم)
└── QUICK_START.md                  # دليل البدء السريع (من النظام القديم)
```

---

## 🚀 التثبيت والتشغيل

### المتطلبات
- Firebase Project مع Firestore
- متصفح حديث (Chrome, Edge, Firefox)

### الخطوات

#### 1. إعداد Firebase
```javascript
// في backend-api.js، قم بتحديث firebaseConfig
const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_AUTH_DOMAIN",
  projectId: "YOUR_PROJECT_ID",
  // ...
};
```

#### 2. رفع قواعد Firestore
```bash
# استخدم Firebase CLI
firebase deploy --only firestore:rules
```

أو انسخ محتوى `firestore.rules` إلى Firestore Rules في Firebase Console.

#### 3. تشغيل Migration
افتح Console في المتصفح وقم بتشغيل:
```javascript
import { runMigration, verifyMigration } from './migration-script.js';

// تشغيل الترحيل
const result = await runMigration(db);
console.log(result);

// التحقق من الترحيل
const verification = await verifyMigration(db);
console.log(verification);
```

#### 4. فتح التطبيق
افتح `index.html` في المتصفح أو ارفع الملفات إلى خادم ويب.

---

## 📖 الاستخدام

### تسجيل الدخول
استخدم بيانات الاعتماد الموجودة في النظام القديم، أو أنشئ مستخدمين جدد في Firestore.

**مثال (Admin):**
```
Username: admin
Password: 1234
```

### الواجهات الرئيسية

#### 1. لوحة التحكم (Dashboard)
- عرض KPIs، Heatmap، Flow View، Alerts، Tasks

#### 2. Hall Control
- تحديث أعداد القاعات يدوياً
- اعتماد الأعداد مع طلب سبب عند الحاجة

#### 3. طلبات النقل (Requests)
- إنشاء طلبات جديدة
- قبول/رفض/بدء نقل/مصادقة الطلبات

#### 4. إدارة القاعات (Halls)
- إضافة/تعديل/حذف القاعات
- عرض تفاصيل القاعات

#### 5. سجل العمليات (Audit Log)
- عرض جميع العمليات الحساسة (Admin فقط)

---

## 🧪 الاختبارات

### تشغيل اختبارات القبول
```javascript
import { runTests } from './acceptance-tests.js';

await runTests();
```

### حالات الاختبار
1. ✅ Hall Scope: InternalUser لا يستطيع قبول طلب ليس لقاعته
2. ✅ Double Decrement: لا يحدث خصم مزدوج
3. ✅ Viewer Permissions: Viewer لا يستطيع التعديل
4. ✅ Commit Count: Commit يولّد AuditLog
5. ✅ Mismatch Comment: Mismatch يلزم تعليق
6. ✅ Assigned Names: اسم المُسند له يظهر

---

## 🔧 التخصيص

### إضافة دور جديد
1. أضف الدور في `ROLES` في `backend-api.js`
2. حدد الصلاحيات في `ROLE_PERMISSIONS`
3. حدّث `firestore.rules` لتشمل الدور الجديد

### إضافة حالة جديدة للطلبات
1. أضف الحالة في `REQUEST_STATES` في `backend-api.js`
2. حدّث `VALID_TRANSITIONS` لتشمل الانتقالات الجديدة
3. أضف منطق المعالجة في `workflow-engine.js`

---

## 📚 التوثيق الإضافي

- **[ANALYSIS.md](./ANALYSIS.md)**: تحليل شامل للنظام الحالي والمتطلبات الجديدة
- **[DATA_MODEL.md](./DATA_MODEL.md)**: تصميم نموذج البيانات والـ Schema
- **[DOCUMENTATION.md](./DOCUMENTATION.md)**: توثيق الأدوار، الانتقالات، والاختبارات
- **[NEW_FEATURES_README.md](./NEW_FEATURES_README.md)**: ميزات النظام السابق (v32)

---

## 🛡️ الأمان

### Defense in Depth
التحقق من الصلاحيات يتم في 3 طبقات:
1. **UI**: إخفاء الأزرار غير المسموح بها
2. **Frontend Logic**: التحقق قبل إرسال الطلب
3. **Firestore Rules**: التحقق النهائي على مستوى قاعدة البيانات

### Audit Log
جميع العمليات الحساسة يتم تسجيلها في `AuditLog` مع:
- معلومات المستخدم (actor)
- نوع العملية (action)
- الكيان المتأثر (entity)
- القيم قبل وبعد (before/after)
- السبب (reason)

---

## 🤝 المساهمة

هذا النظام تم تطويره بناءً على متطلبات محددة. لأي تعديلات أو تحسينات:
1. راجع `ANALYSIS.md` لفهم المتطلبات
2. اتبع معايير الكود الموجودة
3. أضف اختبارات لأي ميزة جديدة
4. حدّث التوثيق

---

## 📄 الترخيص

هذا المشروع خاص بـ B36 Hall Management System.

---

## 📞 الدعم

لأي استفسارات أو مشاكل، يرجى مراجعة التوثيق أو الاتصال بفريق التطوير.

---

**B36 v33 Enhanced - The Ultimate Hall Management System** 💎

تم التطوير بواسطة **Manus AI** - يناير 2026
