# 📘 دليل التنفيذ خطوة بخطوة (Implementation Guide)

هذا الدليل يوضح كيفية دمج الملفات الجديدة مع النظام الحالي وتنفيذ التحديثات بشكل آمن.

---

## 🎯 الهدف

دمج التحديثات الجديدة (v33) مع النظام الحالي (v32) **بدون كسر البيانات الموجودة** وبطريقة تدريجية آمنة.

---

## 📋 خطة التنفيذ

### المرحلة 1: التحضير (Preparation)

#### 1.1 النسخ الاحتياطي
```bash
# قم بعمل نسخة احتياطية كاملة من Firestore
# استخدم Firebase Console → Firestore → Export
```

**مهم جداً:** لا تتخطى هذه الخطوة!

#### 1.2 إنشاء بيئة تجريبية (Staging)
- أنشئ Firebase Project جديد للتجربة
- انسخ البيانات الحالية إلى البيئة التجريبية
- نفّذ جميع الخطوات التالية في البيئة التجريبية أولاً

---

### المرحلة 2: تحديث قواعد Firestore

#### 2.1 رفع القواعد الجديدة
```bash
# استخدم Firebase CLI
firebase deploy --only firestore:rules
```

أو انسخ محتوى `firestore.rules` إلى Firebase Console.

#### 2.2 التحقق من القواعد
- افتح Firebase Console → Firestore → Rules
- تأكد من عدم وجود أخطاء في الصياغة
- اختبر القواعد باستخدام Rules Playground

---

### المرحلة 3: تشغيل Migration

#### 3.1 رفع ملف Migration
ارفع `migration-script.js` إلى نفس مجلد المشروع.

#### 3.2 تشغيل Migration
افتح Console في المتصفح (F12) وقم بتشغيل:

```javascript
// استيراد المكتبات
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-app.js";
import { getFirestore } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-firestore.js";
import { runMigration, verifyMigration } from './migration-script.js';

// تهيئة Firebase (استخدم نفس الـ config الموجود في app.js)
const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_AUTH_DOMAIN",
  projectId: "YOUR_PROJECT_ID",
  // ...
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

// تشغيل الترحيل
console.log("🚀 بدء الترحيل...");
const result = await runMigration(db);
console.log("✅ نتيجة الترحيل:", result);

// التحقق من الترحيل
console.log("🔍 بدء التحقق...");
const verification = await verifyMigration(db);
console.log("✅ نتيجة التحقق:", verification);
```

#### 3.3 مراجعة النتائج
- تأكد من أن جميع الفحوصات نجحت (✅)
- إذا فشل أي فحص، راجع السجلات (Logs) وأصلح المشكلة
- **لا تتابع إلى المرحلة التالية إلا بعد نجاح جميع الفحوصات**

---

### المرحلة 4: دمج الملفات الجديدة

#### 4.1 إضافة الملفات الجديدة
انسخ الملفات التالية إلى مجلد المشروع:
```
backend-api.js
workflow-engine.js
hall-control-ui.js
dashboard-command-center.js
```

#### 4.2 تحديث index.html
أضف الـ imports الجديدة في `<head>`:

```html
<!-- الملفات الجديدة -->
<script type="module" src="backend-api.js"></script>
<script type="module" src="workflow-engine.js"></script>
<script type="module" src="hall-control-ui.js"></script>
<script type="module" src="dashboard-command-center.js"></script>
```

#### 4.3 تحديث app.js
استبدل الوظائف القديمة بالوظائف الجديدة تدريجياً:

**مثال: استبدال commitHallCount**

```javascript
// القديم (في app.js)
async function commitHallCount(hallId, newCount) {
  await updateDoc(doc(db, 'halls', hallId), {
    currentCount: newCount
  });
}

// الجديد (استيراد من backend-api.js)
import { commitHallCount } from './backend-api.js';

// الاستخدام
await commitHallCount(db, currentUser, hallId, newCount, reason);
```

**مثال: استبدال acceptRequest**

```javascript
// القديم
async function acceptRequest(requestId) {
  await updateDoc(doc(db, 'transferRequests', requestId), {
    status: 'accepted'
  });
}

// الجديد
import { acceptRequest } from './backend-api.js';

await acceptRequest(db, currentUser, requestId);
```

---

### المرحلة 5: تحديث الواجهات

#### 5.1 Hall Control UI
استبدل واجهة إدارة القاعات القديمة بـ `hall-control-ui.js`:

```javascript
// في app.js
import { renderHallControlView } from './hall-control-ui.js';

function showView(view) {
  if (view === 'halls') {
    renderHallControlView(db, currentUser, halls);
  }
  // ...
}
```

#### 5.2 Dashboard Command Center
استبدل الداشبورد القديم بـ `dashboard-command-center.js`:

```javascript
import { renderCommandCenter } from './dashboard-command-center.js';

function showView(view) {
  if (view === 'dashboard') {
    renderCommandCenter(db, currentUser, halls, requests);
  }
  // ...
}
```

---

### المرحلة 6: الاختبار

#### 6.1 اختبارات يدوية
قم بتسجيل الدخول بأدوار مختلفة واختبر:

**Admin:**
- [ ] اعتماد عدد قاعة مع تجاوز السعة
- [ ] عرض سجل العمليات
- [ ] إنشاء طلب نقل

**InternalSupervisor:**
- [ ] اعتماد عدد قاعة
- [ ] إنشاء طلب waiting→interview
- [ ] تعيين منظم مسار

**InternalUser:**
- [ ] اعتماد عدد للقاعة المُعيّن عليها فقط
- [ ] قبول طلب للقاعة المُعيّن عليها
- [ ] محاولة قبول طلب لقاعة أخرى (يجب أن يفشل)

**Viewer:**
- [ ] عرض الداشبورد
- [ ] محاولة التعديل (يجب أن يفشل)

#### 6.2 اختبارات تلقائية
```javascript
import { runTests } from './acceptance-tests.js';

await runTests();
```

تأكد من نجاح جميع الاختبارات.

---

### المرحلة 7: النشر (Deployment)

#### 7.1 التحقق النهائي
- [ ] جميع الاختبارات نجحت
- [ ] لا توجد أخطاء في Console
- [ ] جميع الواجهات تعمل بشكل صحيح
- [ ] البيانات الحالية لم تتأثر

#### 7.2 النشر إلى الإنتاج
```bash
# رفع الملفات إلى الخادم
# أو استخدام Firebase Hosting
firebase deploy --only hosting
```

#### 7.3 المراقبة
- راقب السجلات (Logs) في Firebase Console
- راقب أي أخطاء في Firestore
- راقب تعليقات المستخدمين

---

## 🔄 التراجع (Rollback)

إذا حدثت مشاكل بعد النشر:

### خطوة 1: استعادة النسخة الاحتياطية
```bash
# استخدم Firebase Console → Firestore → Import
# اختر النسخة الاحتياطية التي أخذتها في المرحلة 1
```

### خطوة 2: استعادة الملفات القديمة
- احذف الملفات الجديدة
- استعد الملفات القديمة من Git أو النسخة الاحتياطية

### خطوة 3: التحقق
- تأكد من أن النظام القديم يعمل بشكل صحيح
- راجع السجلات لفهم سبب الفشل

---

## 📊 جدول المراحل الزمني المقترح

| المرحلة | المدة المقدرة | المسؤول |
|:---|:---:|:---|
| 1. التحضير | 1 ساعة | DevOps |
| 2. تحديث Firestore Rules | 30 دقيقة | Backend Dev |
| 3. تشغيل Migration | 1-2 ساعة | Backend Dev |
| 4. دمج الملفات | 2-3 ساعات | Full-Stack Dev |
| 5. تحديث الواجهات | 3-4 ساعات | Frontend Dev |
| 6. الاختبار | 4-6 ساعات | QA Team |
| 7. النشر | 1 ساعة | DevOps |
| **المجموع** | **12-18 ساعة** | |

---

## ⚠️ ملاحظات مهمة

1. **لا تنفذ في الإنتاج مباشرة**: استخدم بيئة تجريبية أولاً.
2. **النسخ الاحتياطي إلزامي**: لا تتخطى هذه الخطوة أبداً.
3. **الاختبار الشامل**: اختبر جميع الأدوار والسيناريوهات.
4. **المراقبة المستمرة**: راقب النظام بعد النشر لمدة أسبوع على الأقل.
5. **التوثيق**: وثّق أي مشاكل واجهتها وكيف حللتها.

---

## 📞 الدعم

إذا واجهت أي مشاكل أثناء التنفيذ:
1. راجع السجلات (Console Logs + Firestore Logs)
2. راجع التوثيق في `DOCUMENTATION.md`
3. تواصل مع فريق التطوير

---

**حظاً موفقاً في التنفيذ!** 🚀
