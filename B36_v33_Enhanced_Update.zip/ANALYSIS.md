# تحليل النظام الحالي والمتطلبات الجديدة

## 📊 النظام الحالي (B36 v32 Enhanced)

### التقنيات المستخدمة
- **Frontend**: Vanilla JavaScript (ES6 Modules)
- **Backend**: Firebase Firestore
- **UI**: Custom CSS + Phosphor Icons
- **Charts**: Chart.js
- **PDF**: jsPDF

### الأدوار الموجودة
1. **يوزر_المدير_العام** (ADMIN)
2. **يوزر_المنظم_الخارجي_مشرف** (EXTERNAL_SUPERVISOR)
3. **يوزر_المنظم_الخارجي_عادي** (EXTERNAL_REGULAR)
4. **يوزر_المنظم_الداخلي_مشرف_المبنى** (INTERNAL_SUPERVISOR)
5. **يوزر_المنظم_الداخلي_عادي** (INTERNAL_REGULAR)
6. **يوزر_العرض** (VIEWER)
7. **منظم المسار** (INTERNAL_REGULAR + isPathOrganizer flag)

### حالات الطلبات الموجودة
```
draft → pending → accepted/rejected
                    ↓
              in_transit → arrived → closed
```

### الميزات الموجودة
✅ RBAC System مع صلاحيات محددة
✅ State Machine للطلبات
✅ Dashboard أساسي
✅ Analytics متقدمة مع رسوم بيانية
✅ PDF Export
✅ Super Admin Mode (لتجربة الأدوار)
✅ Audit Log أساسي

---

## 🎯 المتطلبات الجديدة (حسب المواصفات)

### 1. نموذج البيانات المحدث

#### جدول Halls (محدث)
```javascript
{
  id: string,
  name: string,
  type: 'waiting' | 'interview',
  capacity: number,
  currentCount: number,        // العدد المعتمد
  draftCount: number,          // ⭐ جديد: العدد المسودة
  lastCommittedBy: string,     // ⭐ جديد
  lastCommittedAt: timestamp,  // ⭐ جديد
  createdAt: timestamp,
  updatedAt: timestamp
}
```

#### جدول OutsideQueue (جديد)
```javascript
{
  id: 'global',
  currentOutsideCount: number,
  lastUpdatedBy: string,
  lastUpdatedAt: timestamp
}
```

#### جدول TransferRequests (محدث)
```javascript
{
  id: string,
  requestType: 'outside_to_waiting' | 'waiting_to_interview' | 'interview_to_interview',
  fromHallId: string | null,
  toHallId: string,
  requestedCount: number,
  
  // ⭐ تفاصيل التعيين (محسّنة)
  assignedToUserId: string,
  assignedToName: string,
  assignedByUserId: string,
  assignedByName: string,
  pathOrganizerId: string | null,    // ⭐ جديد
  pathOrganizerName: string | null,  // ⭐ جديد
  
  status: 'draft' | 'pending' | 'accepted' | 'rejected' | 'in_transit' | 'arrived' | 'closed',
  
  // التواقيت
  createdAt: timestamp,
  submittedAt: timestamp | null,
  acceptedAt: timestamp | null,
  acceptedBy: string | null,
  rejectedAt: timestamp | null,
  rejectedBy: string | null,
  transitStartedAt: timestamp | null,
  arrivedAt: timestamp | null,
  confirmedAt: timestamp | null,
  confirmedBy: string | null,
  closedAt: timestamp | null,
  
  // المصادقة
  actualArrivedCount: number | null,
  delta: number | null,              // الفرق بعد المصادقة
  comment: string | null,
  mismatchReason: string | null      // ⭐ جديد: سبب الفرق
}
```

#### جدول HallAssignments (جديد)
```javascript
{
  id: string,
  userId: string,
  hallId: string,
  roleInHall: 'receiver' | 'manager' | 'pathOrganizer',
  assignedAt: timestamp,
  assignedBy: string
}
```

#### جدول AuditLog (محسّن)
```javascript
{
  id: string,
  actorId: string,
  actorName: string,
  actorRole: string,
  action: string,              // 'commit_count', 'accept_request', 'confirm_arrival', etc.
  entityType: string,          // 'hall', 'request', 'user', etc.
  entityId: string,
  before: object | null,       // ⭐ القيمة قبل التعديل
  after: object | null,        // ⭐ القيمة بعد التعديل
  reason: string | null,       // ⭐ السبب (إلزامي في بعض الحالات)
  createdAt: timestamp
}
```

---

### 2. Workflow المحدث (منع Double Decrement)

#### القاعدة الأساسية
**خيار A (المختار):** الخصم يحدث عند `in_transit` فقط
```
1. PENDING → ACCEPTED: لا خصم
2. ACCEPTED → IN_TRANSIT: خصم requestedCount من fromHall
3. IN_TRANSIT → ARRIVED: لا خصم
4. ARRIVED → CLOSED: إضافة actualArrivedCount إلى toHall
```

#### أنواع الطلبات

**A. outside_to_waiting**
- **المنشئ:** ExternalSupervisor فقط
- **المستلم:** مسؤول قاعة الانتظار (InternalUser/InternalSupervisor)
- **الخطوات:**
  1. ExternalSupervisor ينشئ الطلب (draft)
  2. يرسله (pending)
  3. المستلم يقبل (accepted)
  4. المستلم يبدأ النقل (in_transit) → خصم من outdoor_queue
  5. المستلم يصادق الوصول (arrived) → إضافة إلى toHall
  6. إغلاق تلقائي (closed)

**B. waiting_to_interview**
- **المنشئ:** InternalSupervisor فقط
- **PathOrganizer:** يجب تعيينه
- **الخطوات:**
  1. InternalSupervisor ينشئ الطلب ويعيّن pathOrganizer (draft)
  2. يرسله (pending)
  3. مسؤول قاعة المقابلات يقبل (accepted)
  4. PathOrganizer يبدأ النقل (in_transit) → خصم من fromHall
  5. مسؤول قاعة المقابلات يصادق (arrived) → إضافة إلى toHall
  6. إغلاق تلقائي (closed)

**C. interview_to_interview**
- **المنشئ:** InternalSupervisor فقط
- **نفس آلية** waiting_to_interview

---

### 3. Hall Control UI (عداد يدوي)

#### الواجهة
```
┌─────────────────────────────────────┐
│ قاعة الانتظار 1                     │
├─────────────────────────────────────┤
│ العدد الحالي: 45                    │
│ المتبقي: 5 / السعة: 50              │
│                                     │
│ عداد يدوي:                          │
│  [-1]  [__50__]  [+1]              │
│                                     │
│  [اعتماد العدد] [إلغاء]            │
│                                     │
│ آخر تحديث: 2026-01-26 10:30        │
│ بواسطة: أحمد محمد                   │
└─────────────────────────────────────┘
```

#### المنطق
- `draftCount` يبدأ بقيمة `currentCount`
- الأزرار +1/-1 تعدل `draftCount` فقط (في الذاكرة)
- زر "اعتماد العدد" ينفذ:
  ```javascript
  if (Math.abs(draftCount - currentCount) > 5 || draftCount < currentCount) {
    // طلب سبب إلزامي
  }
  if (draftCount > capacity && role !== ADMIN) {
    // رفض
  }
  // تحديث currentCount
  // تسجيل في AuditLog
  ```

#### الصلاحيات
- **InternalUser:** Commit للقاعات المعيّن عليها فقط
- **InternalSupervisor:** Commit لكل القاعات
- **Admin:** كل شيء + تجاوز السعة مع سبب
- **External roles + Viewer:** لا وصول

---

### 4. Dashboard Command Center

#### المكونات المطلوبة

**A. KPI Ribbon**
```javascript
{
  outsideCount: number,           // خارج المبنى
  totalInside: number,            // إجمالي داخل المبنى
  totalRemainingCapacity: number, // المتبقي
  throughput30min: number,        // عدد تم نقله آخر 30 دقيقة
  throughput60min: number,        // عدد تم نقله آخر 60 دقيقة
  mismatchRate: number            // نسبة الفروقات (%)
}
```

**B. Heatmap Grid**
- شبكة من Tiles تمثل القاعات
- كل Tile يحتوي:
  - اللون حسب % الامتلاء (أخضر → أصفر → أحمر)
  - current / remaining / capacity
  - سهم اتجاه (↑ تصاعد / ↓ تناقص)
  - Sparkline صغيرة لآخر 60 دقيقة
- عند الضغط: Drawer يظهر تفاصيل القاعة

**C. Flow View**
- مخطط Sankey-like يوضح:
  ```
  Outside (50) ─────────→ Waiting Halls (100) ─────────→ Interview Halls (80)
                 30/hr                      20/hr
  ```
- سماكة الخط تعكس معدل التدفق
- تحذير عند Bottleneck

**D. Alerts Panel**
```javascript
[
  { type: 'warning', message: 'قاعة المقابلات 2 امتلأت بنسبة 85%' },
  { type: 'error', message: 'طلب #123 معلق منذ 45 دقيقة' },
  { type: 'info', message: 'نسبة mismatch عالية في قاعة الانتظار 1' }
]
```

**E. Task Inbox (حسب الدور)**
- **ExternalSupervisor:** طلبات outside→waiting بانتظار قبول
- **PathOrganizer:** مهام النقل المكلف بها
- **Hall Receiver:** مهام مصادقة الوصول
- **InternalSupervisor:** لوحة توازن + اقتراحات

---

### 5. الصلاحيات المحدثة

#### نطاق القاعة (Hall Scope)
```javascript
function canActOnRequest(user, request) {
  // Admin يستطيع كل شيء
  if (user.role === ROLES.ADMIN) return true;
  
  // InternalSupervisor يستطيع كل شيء في مبناه
  if (user.role === ROLES.INTERNAL_SUPERVISOR) return true;
  
  // InternalUser فقط للقاعات المعيّن عليها
  if (user.role === ROLES.INTERNAL_REGULAR) {
    const assignment = hallAssignments.find(
      a => a.userId === user.id && a.hallId === request.toHallId
    );
    return !!assignment;
  }
  
  return false;
}
```

#### منع الخصم المكرر
```javascript
async function transitionToInTransit(requestId) {
  const request = await getRequest(requestId);
  
  // التحقق من أن الحالة صحيحة
  validateStateTransition(request.status, 'in_transit');
  
  // الخصم يحدث هنا فقط
  if (request.fromHallId) {
    await updateDoc(doc(db, 'halls', request.fromHallId), {
      currentCount: increment(-request.requestedCount)
    });
  } else {
    // outside_to_waiting
    await updateDoc(doc(db, 'outsideQueue', 'global'), {
      currentOutsideCount: increment(-request.requestedCount)
    });
  }
  
  // تحديث حالة الطلب
  await updateDoc(doc(db, 'transferRequests', requestId), {
    status: 'in_transit',
    transitStartedAt: serverTimestamp()
  });
  
  // تسجيل في AuditLog
  await logAudit({
    action: 'start_transit',
    entityType: 'request',
    entityId: requestId,
    before: { status: 'accepted' },
    after: { status: 'in_transit', decremented: request.requestedCount }
  });
}
```

---

### 6. اختبارات القبول

```javascript
// Test 1: InternalUser لا يستطيع قبول طلب ليس لقاعته
async function test_hallScope() {
  const user = { id: 'user1', role: ROLES.INTERNAL_REGULAR };
  const request = { id: 'req1', toHallId: 'hall2' };
  // user معيّن على hall1 فقط
  
  const result = canActOnRequest(user, request);
  assert(result === false, 'يجب رفض الوصول');
}

// Test 2: لا يحدث خصم مزدوج
async function test_noDoubleDecrement() {
  const initialCount = 50;
  const requestedCount = 10;
  
  // إنشاء طلب
  const requestId = await createRequest({ requestedCount });
  
  // قبول
  await acceptRequest(requestId);
  
  // بدء النقل (خصم هنا)
  await transitionToInTransit(requestId);
  const countAfterTransit = await getHallCount(fromHallId);
  assert(countAfterTransit === 40, 'يجب خصم 10 فقط');
  
  // وصول (لا خصم)
  await confirmArrival(requestId, { actualArrivedCount: 9 });
  const countAfterArrival = await getHallCount(fromHallId);
  assert(countAfterArrival === 40, 'يجب عدم الخصم مرة أخرى');
}

// Test 3: Viewer لا يستطيع التعديل
async function test_viewerReadOnly() {
  const user = { id: 'viewer1', role: ROLES.VIEWER };
  
  try {
    await commitHallCount(user, 'hall1', 55);
    assert(false, 'يجب رفض العملية');
  } catch (error) {
    assert(error.message.includes('صلاحية'), 'يجب رفض بسبب الصلاحيات');
  }
}

// Test 4: Commit يولّد AuditLog
async function test_commitGeneratesAudit() {
  const user = { id: 'admin1', role: ROLES.ADMIN };
  const hallId = 'hall1';
  const newCount = 55;
  
  await commitHallCount(user, hallId, newCount, 'تعديل يدوي');
  
  const auditLogs = await getAuditLogs({ entityId: hallId, limit: 1 });
  assert(auditLogs.length === 1, 'يجب إنشاء سجل');
  assert(auditLogs[0].action === 'commit_count', 'يجب تسجيل العملية');
}

// Test 5: Mismatch يلزم تعليق
async function test_mismatchRequiresComment() {
  const requestId = 'req1';
  const requestedCount = 10;
  const actualArrivedCount = 8;
  
  try {
    await confirmArrival(requestId, { actualArrivedCount, comment: null });
    assert(false, 'يجب رفض بدون تعليق');
  } catch (error) {
    assert(error.message.includes('تعليق'), 'يجب طلب تعليق');
  }
}

// Test 6: اسم المُسند له يظهر
async function test_assignedToShown() {
  const request = await getRequest('req1');
  
  assert(request.assignedToName !== null, 'يجب وجود اسم المُسند له');
  assert(request.assignedByName !== null, 'يجب وجود اسم المُسند من');
}
```

---

## 🔧 خطة التنفيذ

### المرحلة 1: تحديث نموذج البيانات
- [ ] إضافة حقول `draftCount`, `lastCommittedBy`, `lastCommittedAt` إلى Halls
- [ ] إنشاء جدول OutsideQueue
- [ ] إضافة حقول `pathOrganizerId`, `pathOrganizerName`, `mismatchReason` إلى TransferRequests
- [ ] إنشاء جدول HallAssignments
- [ ] تحسين جدول AuditLog بحقول `before`, `after`, `reason`

### المرحلة 2: Backend API
- [ ] تطوير `commitHallCount()` مع التحقق من الصلاحيات
- [ ] تطوير `canActOnRequest()` مع Hall Scope
- [ ] تحديث `transitionToInTransit()` لمنع Double Decrement
- [ ] تطوير `assignPathOrganizer()`
- [ ] تطوير `logAudit()` المحسّن

### المرحلة 3: Hall Control UI
- [ ] تصميم واجهة العداد اليدوي
- [ ] تطوير منطق Draft → Commit
- [ ] إضافة نافذة طلب السبب
- [ ] ربط الصلاحيات بالواجهة

### المرحلة 4: Dashboard Command Center
- [ ] تطوير KPI Ribbon
- [ ] تطوير Heatmap Grid
- [ ] تطوير Flow View (Sankey-like)
- [ ] تطوير Alerts Panel
- [ ] تطوير Task Inbox (حسب الدور)

### المرحلة 5: Workflow Engine
- [ ] تحديث State Machine
- [ ] تطوير منطق outside_to_waiting
- [ ] تطوير منطق waiting_to_interview
- [ ] تطوير منطق interview_to_interview
- [ ] إضافة التحقق من PathOrganizer

### المرحلة 6: Migration
- [ ] كتابة سكريبت لإضافة الحقول الجديدة
- [ ] كتابة سكريبت لنقل البيانات الحالية
- [ ] اختبار Migration على بيانات تجريبية

### المرحلة 7: الاختبارات والتوثيق
- [ ] كتابة اختبارات القبول الـ6
- [ ] كتابة توثيق الصلاحيات
- [ ] كتابة توثيق الانتقالات
- [ ] كتابة دليل المستخدم

---

## 📝 ملاحظات مهمة

### Defense in Depth
- التحقق من الصلاحيات في **3 طبقات**:
  1. UI (إخفاء الأزرار)
  2. Frontend Logic (قبل الإرسال)
  3. Backend/Firestore Rules (RLS)

### منع Double Decrement
- **نقطة خصم واحدة فقط:** عند `in_transit`
- **لا خصم في:** `accepted` أو `arrived` أو `closed`

### Audit Log الشامل
- **كل عملية حساسة** يجب تسجيلها:
  - Commit count
  - Accept/Reject request
  - Start transit
  - Confirm arrival
  - Assign user

### Hall Scope
- **InternalUser** يرى ويتفاعل فقط مع قاعاته
- **InternalSupervisor** يرى كل القاعات
- **Admin** يرى ويتحكم بكل شيء

---

## ✅ معايير النجاح

1. ✅ لا يحدث خصم مزدوج للأعداد أبداً
2. ✅ كل مستخدم يرى فقط ما يخصه (Hall Scope)
3. ✅ Viewer لا يستطيع التعديل حتى لو عرف الرابط
4. ✅ كل Commit يولّد AuditLog
5. ✅ كل Mismatch يلزم تعليق وسبب
6. ✅ اسم المُسند له يظهر في كل طلب
7. ✅ Dashboard يعرض بيانات حقيقية ومفيدة
8. ✅ Migration لا يكسر البيانات الحالية
9. ✅ الاختبارات الـ6 تنجح كلها
10. ✅ التوثيق واضح وشامل
