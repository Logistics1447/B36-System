
// ============================================
// B36 SYSTEM - VERSION 32 (PROFESSIONAL RBAC & WORKFLOW)
// ============================================

import { initializeApp } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-app.js";
import { 
    getFirestore, collection, doc, setDoc, getDoc, updateDoc, 
    onSnapshot, query, where, orderBy, serverTimestamp, increment, writeBatch 
} from "https://www.gstatic.com/firebasejs/10.7.1/firebase-firestore.js";

// Firebase Configuration (Using existing config)
const firebaseConfig = {
    apiKey: "AIzaSyAs-Existing-Key",
    authDomain: "b36-system.firebaseapp.com",
    projectId: "b36-system",
    storageBucket: "b36-system.appspot.com",
    messagingSenderId: "123456789",
    appId: "1:123456789:web:abcdef"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

// ============================================
// CONSTANTS & ROLES
// ============================================

const ROLES = {
    EXTERNAL_SUPERVISOR: 'external_supervisor', // منظم خارجي (مشرف)
    EXTERNAL_REGULAR: 'external_regular',       // منظم خارجي (عادي)
    INTERNAL_SUPERVISOR: 'internal_supervisor', // منظم داخلي (مشرف المبنى)
    INTERNAL_REGULAR: 'internal_regular',       // منظم داخلي (عادي)
    ADMIN: 'admin',                             // مدير عام
    VIEWER: 'viewer'                            // يوزر العرض
};

const PERMISSIONS = {
    MANAGE_OUTSIDE_COUNT: 'manage_outside_count',
    CREATE_OUTSIDE_TO_WAITING: 'create_outside_to_waiting',
    ACCEPT_REJECT_REQUEST: 'accept_reject_request',
    CONFIRM_ARRIVAL: 'confirm_arrival',
    CREATE_WAITING_TO_INTERVIEW: 'create_waiting_to_interview',
    ASSIGN_PATH_ORGANIZER: 'assign_path_organizer',
    EXECUTE_TRANSIT: 'execute_transit',
    CONFIRM_INTERVIEW_HALL: 'confirm_interview_hall',
    MANAGE_HALLS: 'manage_halls',
    MANAGE_USERS: 'manage_users',
    VIEW_AUDIT_LOG: 'view_audit_log',
    VIEW_ANALYTICS: 'view_analytics'
};

const ROLE_PERMISSIONS = {
    [ROLES.EXTERNAL_SUPERVISOR]: [PERMISSIONS.MANAGE_OUTSIDE_COUNT, PERMISSIONS.CREATE_OUTSIDE_TO_WAITING, PERMISSIONS.VIEW_ANALYTICS],
    [ROLES.EXTERNAL_REGULAR]: [PERMISSIONS.MANAGE_OUTSIDE_COUNT],
    [ROLES.INTERNAL_SUPERVISOR]: [PERMISSIONS.ACCEPT_REJECT_REQUEST, PERMISSIONS.CONFIRM_ARRIVAL, PERMISSIONS.CREATE_WAITING_TO_INTERVIEW, PERMISSIONS.ASSIGN_PATH_ORGANIZER, PERMISSIONS.VIEW_ANALYTICS],
    [ROLES.INTERNAL_REGULAR]: [PERMISSIONS.ACCEPT_REJECT_REQUEST, PERMISSIONS.CONFIRM_ARRIVAL, PERMISSIONS.EXECUTE_TRANSIT, PERMISSIONS.CONFIRM_INTERVIEW_HALL],
    [ROLES.ADMIN]: Object.values(PERMISSIONS),
    [ROLES.VIEWER]: [PERMISSIONS.VIEW_ANALYTICS]
};

const REQUEST_STATUS = {
    DRAFT: 'draft',
    PENDING: 'pending',
    ACCEPTED: 'accepted',
    REJECTED: 'rejected',
    IN_TRANSIT: 'in_transit',
    ARRIVED: 'arrived',
    CLOSED: 'closed'
};

// ============================================
// STATE MANAGEMENT
// ============================================

let currentUser = null;
let halls = [];
let users = [];
let transferRequests = [];
let globalStats = { outdoor_queue: 0, served: 0, missing_count: 0 };
let currentView = 'dashboard';

// ============================================
// CORE FUNCTIONS
// ============================================

function hasPermission(permission) {
    if (!currentUser) return false;
    return ROLE_PERMISSIONS[currentUser.role]?.includes(permission) || false;
}

async function logActivity(action, details, entityType = null, entityId = null, oldValue = null, newValue = null) {
    try {
        await setDoc(doc(collection(db, "audit_log")), {
            userId: currentUser.id,
            userName: currentUser.name,
            role: currentUser.role,
            action,
            details,
            entityType,
            entityId,
            oldValue,
            newValue,
            timestamp: serverTimestamp()
        });
    } catch (e) {
        console.error("Audit Log Error:", e);
    }
}

// ============================================
// AUTHENTICATION
// ============================================

window.login = async (username, password) => {
    setLoading(true);
    try {
        const userDoc = await getDoc(doc(db, "users", username));
        if (userDoc.exists() && userDoc.data().password === password) {
            currentUser = { id: userDoc.id, ...userDoc.data() };
            localStorage.setItem('b36_user', JSON.stringify(currentUser));
            initApp();
        } else {
            showToast('خطأ في اسم المستخدم أو كلمة المرور', 'error');
        }
    } catch (e) {
        showToast('حدث خطأ أثناء تسجيل الدخول', 'error');
    } finally {
        setLoading(false);
    }
};

// ============================================
// INITIALIZATION
// ============================================

function initApp() {
    document.getElementById('loginPage').classList.add('hidden');
    document.getElementById('mainApp').classList.remove('hidden');
    document.getElementById('userNameDisplay').innerText = currentUser.name;
    document.getElementById('userRoleDisplay').innerText = getRoleLabel(currentUser.role);
    
    buildNavigation();
    startListeners();
}

function startListeners() {
    onSnapshot(collection(db, "halls"), (s) => {
        halls = [];
        s.forEach(d => halls.push({ id: d.id, ...d.data() }));
        updateKPIs();
        renderCurrentView();
    });

    onSnapshot(doc(db, "settings", "global_config"), (s) => {
        if (s.exists()) {
            globalStats = s.data();
            updateKPIs();
        }
    });

    onSnapshot(query(collection(db, "transfer_requests"), orderBy("createdAt", "desc")), (s) => {
        transferRequests = [];
        s.forEach(d => transferRequests.push({ id: d.id, ...d.data() }));
        renderCurrentView();
    });
}

// ============================================
// WORKFLOW ACTIONS
// ============================================

window.createTransferRequest = async (fromType, fromId, toId, count) => {
    if (!hasPermission(PERMISSIONS.CREATE_OUTSIDE_TO_WAITING) && fromType === 'outside') return;
    
    try {
        setLoading(true);
        const reqRef = doc(collection(db, "transfer_requests"));
        const reqData = {
            type: fromType === 'outside' ? 'OUTSIDE_TO_WAITING' : 'WAITING_TO_INTERVIEW',
            fromId,
            toId,
            count: parseInt(count),
            status: REQUEST_STATUS.PENDING,
            createdBy: currentUser.id,
            createdByName: currentUser.name,
            createdAt: serverTimestamp(),
            history: [{ status: REQUEST_STATUS.PENDING, time: new Date(), user: currentUser.name }]
        };
        
        await setDoc(reqRef, reqData);
        await logActivity('CREATE_REQUEST', `إنشاء طلب نقل عدد ${count}`, 'transfer_request', reqRef.id, null, reqData);
        showToast('تم إنشاء الطلب بنجاح', 'success');
    } catch (e) {
        showToast('خطأ في إنشاء الطلب', 'error');
    } finally {
        setLoading(false);
    }
};

window.handleRequestAction = async (requestId, action, actualCount = null, comment = '') => {
    const req = transferRequests.find(r => r.id === requestId);
    if (!req) return;

    let nextStatus = req.status;
    let updateData = { lastUpdated: serverTimestamp() };

    if (action === 'accept') nextStatus = REQUEST_STATUS.ACCEPTED;
    if (action === 'reject') nextStatus = REQUEST_STATUS.REJECTED;
    if (action === 'transit') nextStatus = REQUEST_STATUS.IN_TRANSIT;
    if (action === 'confirm') {
        nextStatus = REQUEST_STATUS.ARRIVED;
        const diff = req.count - parseInt(actualCount);
        updateData.actualCount = parseInt(actualCount);
        updateData.difference = diff;
        updateData.comment = comment;
        updateData.confirmedBy = currentUser.id;
        
        const batch = writeBatch(db);
        batch.update(doc(db, "halls", req.toId), { current: increment(parseInt(actualCount)) });
        if (req.fromId !== 'outside') {
            batch.update(doc(db, "halls", req.fromId), { current: increment(-req.count) });
        } else {
            batch.update(doc(db, "settings", "global_config"), { outdoor_queue: increment(-req.count) });
        }
        
        if (diff > 0) {
            batch.update(doc(db, "settings", "global_config"), { missing_count: increment(diff) });
        }
        await batch.commit();
    }

    updateData.status = nextStatus;
    updateData.history = [...(req.history || []), { status: nextStatus, time: new Date(), user: currentUser.name, comment }];

    await updateDoc(doc(db, "transfer_requests", requestId), updateData);
    await logActivity('UPDATE_REQUEST_STATUS', `تحديث حالة الطلب إلى ${nextStatus}`, 'transfer_request', requestId, req.status, nextStatus);
    showToast('تم تحديث الحالة', 'success');
};

// ============================================
// UI RENDERING
// ============================================

function renderDashboard() {
    const content = document.getElementById('contentArea');
    let html = `<h2 class="text-2xl font-black mb-6">لوحة التحكم - ${getRoleLabel(currentUser.role)}</h2>`;
    html += `<div id="kpiContainer" class="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8"></div>`;

    if (hasPermission(PERMISSIONS.MANAGE_OUTSIDE_COUNT)) {
        html += `
        <div class="bg-white dark:bg-slate-800 p-6 rounded-2xl shadow-sm border mb-6">
            <h3 class="font-bold mb-4">إدارة العدد الخارجي</h3>
            <div class="flex items-center gap-4">
                <input type="number" id="outsideInput" class="flex-1 p-3 border rounded-xl" value="${globalStats.outdoor_queue}">
                <button onclick="updateOutsideCount()" class="bg-blue-600 text-white px-6 py-3 rounded-xl font-bold">تحديث العدد</button>
            </div>
        </div>`;
    }

    if (hasPermission(PERMISSIONS.CREATE_OUTSIDE_TO_WAITING)) {
        html += `
        <div class="bg-white dark:bg-slate-800 p-6 rounded-2xl shadow-sm border mb-6">
            <h3 class="font-bold mb-4">إسناد جديد (خارج -> انتظار)</h3>
            <button onclick="showCreateRequestModal('outside')" class="w-full bg-green-600 text-white p-4 rounded-xl font-bold">إنشاء طلب إسناد</button>
        </div>`;
    }

    content.innerHTML = html;
    updateKPIs();
}

function updateKPIs() {
    const container = document.getElementById('kpiContainer');
    if (!container) return;

    const totalWaiting = halls.filter(h => h.type === 'انتظار').reduce((a, b) => a + (b.current || 0), 0);
    const totalInterview = halls.filter(h => h.type === 'مقابلات').reduce((a, b) => a + (b.current || 0), 0);

    container.innerHTML = `
        <div class="bg-orange-50 dark:bg-orange-900/20 p-4 rounded-xl border border-orange-100">
            <span class="text-xs text-orange-600 block mb-1">خارج المبنى</span>
            <span class="text-2xl font-black">${globalStats.outdoor_queue}</span>
        </div>
        <div class="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-xl border border-blue-100">
            <span class="text-xs text-blue-600 block mb-1">في الانتظار</span>
            <span class="text-2xl font-black">${totalWaiting}</span>
        </div>
        <div class="bg-purple-50 dark:bg-purple-900/20 p-4 rounded-xl border border-purple-100">
            <span class="text-xs text-purple-600 block mb-1">في المقابلات</span>
            <span class="text-2xl font-black">${totalInterview}</span>
        </div>
        <div class="bg-red-50 dark:bg-red-900/20 p-4 rounded-xl border border-red-100">
            <span class="text-xs text-red-600 block mb-1">الفاقد/التائهين</span>
            <span class="text-2xl font-black">${globalStats.missing_count || 0}</span>
        </div>
    `;
}

function getRoleLabel(role) {
    const labels = {
        [ROLES.EXTERNAL_SUPERVISOR]: 'منظم خارجي (مشرف)',
        [ROLES.EXTERNAL_REGULAR]: 'منظم خارجي (عادي)',
        [ROLES.INTERNAL_SUPERVISOR]: 'مشرف المبنى',
        [ROLES.INTERNAL_REGULAR]: 'منظم داخلي (عادي)',
        [ROLES.ADMIN]: 'مدير عام',
        [ROLES.VIEWER]: 'يوزر عرض'
    };
    return labels[role] || role;
}

function buildNavigation() {
    const nav = document.getElementById('mainNav');
    if (!nav) return;
    let html = `
        <button onclick="showView('dashboard')" class="nav-item">الرئيسية</button>
        <button onclick="showView('requests')" class="nav-item">طلبات النقل</button>
    `;
    
    if (hasPermission(PERMISSIONS.MANAGE_HALLS)) html += `<button onclick="showView('halls')" class="nav-item">إدارة القاعات</button>`;
    if (hasPermission(PERMISSIONS.MANAGE_USERS)) html += `<button onclick="showView('users')" class="nav-item">إدارة المستخدمين</button>`;
    if (hasPermission(PERMISSIONS.VIEW_AUDIT_LOG)) html += `<button onclick="showView('audit')" class="nav-item">سجل العمليات</button>`;
    
    nav.innerHTML = html;
}

function setLoading(show) {
    const loader = document.getElementById('loader');
    if (loader) loader.classList.toggle('hidden', !show);
}

function showToast(msg, type = 'info') {
    Swal.fire({
        toast: true,
        position: 'top-end',
        icon: type,
        title: msg,
        showConfirmButton: false,
        timer: 3000
    });
}

window.showView = (view) => {
    currentView = view;
    renderCurrentView();
};

function renderCurrentView() {
    if (currentView === 'dashboard') renderDashboard();
}

window.updateOutsideCount = async () => {
    const val = document.getElementById('outsideInput').value;
    await updateDoc(doc(db, "settings", "global_config"), { outdoor_queue: parseInt(val) });
    await logActivity('UPDATE_OUTSIDE', `تحديث العدد الخارجي إلى ${val}`);
    showToast('تم التحديث');
};

if (localStorage.getItem('b36_user')) {
    currentUser = JSON.parse(localStorage.getItem('b36_user'));
    initApp();
}
